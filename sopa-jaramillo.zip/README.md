# Bot Guardián Jaramillo
Asistente para documentar testimonios sobre la Sopa Jaramillo.
