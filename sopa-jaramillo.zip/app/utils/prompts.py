# Archivo placeholder para prompts del bot
